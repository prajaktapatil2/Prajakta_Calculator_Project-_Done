# String Calculator Kata (Java, Maven)

This repository contains a Java implementation of the String Calculator TDD kata, with unit tests (JUnit 5).
Follow the TDD steps and commit messages suggested below to show the evolution of the code.

## How to run tests

Requires Java 11+ and Maven.

```bash
mvn -q -DskipTests=false test
```

## What this project includes

- `StringCalculator` (src/main/java) — the implementation with support for:
  - empty strings -> 0
  - comma and newline delimiters
  - custom delimiter at the beginning of the string: `//<delim>\n<numbers>`
  - negative numbers produce an `IllegalArgumentException` with message:
    `negative numbers not allowed -1,-2` (lists all negatives)

- `StringCalculatorTest` (src/test/java) — JUnit 5 test suite covering:
  - empty input, single number, two numbers, multiple numbers
  - newline handling, custom delimiter
  - negative numbers (single and multiple)

## Suggested TDD commit sequence (example)

When you implement this kata on your machine, commit after each step to show TDD progress.

1. `git init` — initial repo
2. `git add pom.xml` and commit:
   - Commit message: `chore: add maven pom`
3. Add failing test for empty string:
   - Commit message: `test: add failing test emptyStringReturnsZero`
4. Implement minimal logic to make it pass:
   - Commit message: `feat: implement add() to return 0 for empty string`
5. Add test for single number:
   - Commit message: `test: add singleNumberReturnsValue`
6. Implement handling for single number:
   - Commit message: `feat: support single number parsing`
7. Add test for two comma-separated numbers:
   - Commit message: `test: add twoNumbersCommaDelimited`
8. Implement parsing and summing:
   - Commit message: `feat: support comma-separated numbers`
9. Add tests for newlines, custom delimiter, negative numbers, etc., following the same pattern.
10. Final refactor commit with clean code and README:
    - Commit message: `refactor: tidy up and add README`

Take screenshots of your terminal showing failing tests -> code change -> passing tests and include them in the repository (recommended `docs/screenshots/`).

## How to publish to GitHub

```bash
git init
git add .
git commit -m "chore: initial project structure and pom"
# Create a repo on GitHub (via website or `gh` CLI). Example using gh:
gh repo create your-username/string-calculator-kata --public --source=. --remote=origin
git push -u origin main
```

## Notes

- This implementation keeps behavior forgiving: when a custom delimiter is declared, comma and newline are still accepted as separators.
- If you'd like stricter behavior (only the custom delimiter allowed), adjust the `delimiterRegex` logic in `StringCalculator`.

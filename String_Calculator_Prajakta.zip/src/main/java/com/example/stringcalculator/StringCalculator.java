package com.example.stringcalculator;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class StringCalculator {

    /**
     * Adds numbers from a string input.
     * Supports:
     * - empty string -> 0
     * - comma and newline as default delimiters
     * - custom single-delimiter declared like: //;\n1;2
     * - throws IllegalArgumentException for negative numbers with a message "negative numbers not allowed <list>"
     */
    public int add(String numbers) {
        if (numbers == null || numbers.isEmpty()) {
            return 0;
        }

        String nums = numbers;
        String delimiterRegex = ",|\n";

        if (numbers.startsWith("//")) {
            int newLineIndex = numbers.indexOf('\n');
            if (newLineIndex == -1) {
                throw new IllegalArgumentException("Invalid input: missing newline after custom delimiter declaration");
            }
            String delim = numbers.substring(2, newLineIndex);

            // Support [delim] notation for multi-char delimiters (basic)
            if (delim.startsWith("[") && delim.endsWith("]")) {
                delim = delim.substring(1, delim.length() - 1);
            }

            String quoted = Pattern.quote(delim);
            // allow comma and newline as well (keeps behavior forgiving)
            delimiterRegex = quoted + "|,|\\n";
            nums = numbers.substring(newLineIndex + 1);
        }

        String[] tokens = nums.split(delimiterRegex);
        List<Integer> negatives = new ArrayList<>();
        int sum = 0;
        for (String token : tokens) {
            if (token == null || token.trim().isEmpty()) continue;
            int n;
            try {
                n = Integer.parseInt(token.trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid number: " + token);
            }
            if (n < 0) negatives.add(n);
            sum += n;
        }

        if (!negatives.isEmpty()) {
            String msg = "negative numbers not allowed " + negatives.stream()
                    .map(Object::toString)
                    .collect(Collectors.joining(","));
            throw new IllegalArgumentException(msg);
        }

        return sum;
    }
}

package com.example.stringcalculator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringCalculatorTest {

    private final StringCalculator calc = new StringCalculator();

    @Test
    void emptyStringReturnsZero() {
        assertEquals(0, calc.add(""));
    }

    @Test
    void singleNumberReturnsValue() {
        assertEquals(1, calc.add("1"));
    }

    @Test
    void twoNumbersCommaDelimited() {
        assertEquals(6, calc.add("1,5"));
    }

    @Test
    void multipleNumbers() {
        assertEquals(10, calc.add("1,2,3,4"));
    }

    @Test
    void newlinesBetweenNumbers() {
        assertEquals(6, calc.add("1\n2,3"));
    }

    @Test
    void customDelimiter() {
        assertEquals(3, calc.add("//;\n1;2"));
    }

    @Test
    void customDelimiterWithNewline() {
        assertEquals(6, calc.add("//;\n1;2\n3"));
    }

    @Test
    void negativeNumbersThrowException() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> calc.add("-1"));
        assertTrue(ex.getMessage().contains("negative numbers not allowed"));
        assertTrue(ex.getMessage().contains("-1"));
    }

    @Test
    void multipleNegativeNumbersListed() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> calc.add("2,-4,3,-5"));
        assertTrue(ex.getMessage().contains("negative numbers not allowed"));
        assertTrue(ex.getMessage().contains("-4"));
        assertTrue(ex.getMessage().contains("-5"));
    }
}
